## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
devtools::load_all("/Users/ihsanbuker/classpackage")
library(tidyverse)

## -----------------------------------------------------------------------------
data <- palmerpenguins::penguins %>%
  tidyr::drop_na()

## -----------------------------------------------------------------------------
# For demonstration sake, we will use Kendall rank correlation
normality_correlation(data, "kendall")

