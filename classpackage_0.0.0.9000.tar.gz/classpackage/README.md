# class_package

Package to organize commonly-used functions for statistics courses at the University of West Florida. 
